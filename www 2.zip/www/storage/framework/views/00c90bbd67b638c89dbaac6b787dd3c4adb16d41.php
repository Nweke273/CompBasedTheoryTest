
<?php $__env->startSection('content'); ?>
<div class="relative flex items-top justify-center min-h-screen col-md-12">
    <div class="container-contact100" style="margin-top: 4%;">
        <div class="wrap-contact100">
            <div class="contact100-form validate-form" id="form">
                <span class="contact100-form-title" style="color: steelBlue;">
                    Please Select a course to check result
                </span>
                <form action="/students/<?php echo e(auth()->user()->student->id); ?>/result" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label text-md-right">Select Course</label>

                        <div class="col-md-8 mb-5">
                            <select class="form-control" name="title" required>
                                <option selected disabled value="">Select Course</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->title); ?>"><?php echo e($course->title ?? ''); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="container-contact100-form-btn">
                            <a href="/students/<?php echo e(auth()->user()->id); ?>/result">
                                <button class="contact100-form-btn" id="submit" value="submit" type="submit">
                                    <span>
                                        Check Result
                                        <i class="zmdi zmdi-arrow-right m-l-8"></i>
                                    </span>
                                </button>
                        </div>
                        </a>
                    </div>
                </form>
           
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fidelia\Desktop\CBT-Theory2\www\resources\views/course-result.blade.php ENDPATH**/ ?>