<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Fidelia\Desktop\CBT-Theory2\www\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>