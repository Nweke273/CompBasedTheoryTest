
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<div class="container-contact100">
    <div class="wrap-contact100">
        <div class="contact100-form validate-form" id="form">
            <?php if(!$results->isEmpty()): ?>
            <table class="table table-bordered">
                <form action="/results/search" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg align-items-end">
                            <div class="form-group" style="display: flex;">
                                <!-- <label for="#">Search</label> -->
                                <div id="search">
                                    <input type="text" class="form-control" placeholder="Enter Keyword" name="keyword" style="border-color: steelblue; border-radius: 4px 0px 0px 4px;" required>
                                </div>
                                <button type="submit" style="font-size: 18px; margin-right: 125px; border-radius: 0px 4px 0px 0px; padding: 4px 8px 4px 8px; color: #fff; background-color: #01131C;">Search</button>
                            </div>
                        </div>
                    </div>
                </form>
                <form>
                    <input class="text-center" type="button" value="Print Result" onClick="window.print()" style="padding: 10px; margin-top: 35px;">
                </form>
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Reg No</th>
                        <th scope="col">Name</th>
                        <th scope="col">Score</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($result->id ?? ''); ?></td>
                        <td><?php echo e($result->reg_no ?? ''); ?></td>
                        <td><?php echo e($result->name ?? ''); ?></td>
                        <td><?php echo e($result->score ?? ''); ?></td>
                        <td><a href="/results/<?php echo e($result->id); ?>/edit">Edit</a></td>
                        <td>
                            <form action="results/<?php echo e($result->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-danger">Delete</button>
                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
            <div style="width: 100%;">
                <h1 class="text-center mb-3 text-info">Results not uploaded yet</h1>
            </div>
            <div class="container-contact100-form-btn mt-3">
                <a href="/home">
                    <button class="contact100-form-btn">
                        <span>
                            Dismiss
                            <i class="zmdi zmdi-arrow-right m-l-8"></i>
                        </span>
                    </button>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\George\Desktop\CBT-Theory2\www\resources\views/lecturer/results.blade.php ENDPATH**/ ?>