<?php echo e($slot); ?>

<?php /**PATH C:\Users\Fidelia\Desktop\CBT-Theory2\www\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>