
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<?php if($message = Session::get('lecturer')): ?>
<div class="row justify-content-center">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header alert alert-success"><?php echo e($message); ?></div>
            <div class="card-body p-2px text-center">
                <div>
                    <span class="text-primary font-weight-bold pb-2">New Lecturer Login Info</span>
                    <p class="pb-2">Copy info and send to lecturer because you will not be able to see it again</p>
                    <div class="ml-5 pl-5">
                        <p class="mb-1 text-left">Name: <?php echo e($name); ?> </p>
                        <p class="mb-1 text-left">Email: <?php echo e($email ?? ''); ?> </p>
                        <p class="mb-1 text-left">Password: <?php echo e($password ?? ''); ?> </h>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(!$lecturers->isEmpty()): ?>
            <div class="card mt-5 text-center">
                <div class="card-header"><?php echo e(__('Lecturers')); ?></div>

                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Course</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php echo e($i=null); ?>

                            <?php $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i+=1); ?></td>
                                <td><?php echo e($lecturer->name ?? ''); ?></td>
                                <td><?php echo e($lecturer->email ?? ''); ?></td>
                                <td><?php echo e($lecturer->lecturer->course ?? ''); ?></td>
                                <td><a href="/lecturers/<?php echo e($lecturer->id); ?>/edit" class="btn btn-warning">Edit</a></td>
                                <td>
                                    <form action="/lecturers/<?php echo e($lecturer->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="submit" value="delete" class="btn btn-danger">
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php else: ?>
            <h4 class="mt-5 pt-5 text-center">You have not created any lecturer!!</h4>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fidelia\Desktop\CBT-Theory2\www\resources\views/lecturer/all.blade.php ENDPATH**/ ?>